import 'dart:io';
import 'dart:ui';

import 'dart:async';
import 'package:draw_cover/base.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';

class MobileGeneration extends BaseGeneration {
  File image;

  @override
  Widget build(BuildContext context) {
    return initMainView();
  }

  Widget initMainView() {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Center(
            child: Stack(
              children: <Widget>[
                image == null ? Text("No image selected") : Image.file(image),
                CustomPaint(
                  painter: painter,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: initActionView(),
    );
  }

  Widget initActionView() {
    return new SpeedDial(
      child: Icon(Icons.menu),
      animatedIcon: AnimatedIcons.menu_close,
      closeManually: true,
      children: [
        SpeedDialChild(
          child: Icon(Icons.camera),
          label: "Camera",
          onTap: getImageFromCam,
        ),
        SpeedDialChild(
          child: Icon(Icons.image),
          label: "Gallery",
          onTap: getImageFromGallery,
        ),
        SpeedDialChild(
          child: Icon(Icons.color_lens),
          label: "Change Color",
          onTap: changeColor,
        ),
        SpeedDialChild(
          child: Icon(Icons.remove),
          label: "Decrease",
          onTap: decreaseCount,
        ),
        SpeedDialChild(
          child: Icon(Icons.add),
          label: "Increase",
          onTap: increaseCount,
        ),
      ],
    );
  }

  Future<Widget> checkImage() async {
    return new Center(
      child: image == null ? Text('No image selected') : Image.file(image),
    );
  }

  Future<Widget> getImageFromCam() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);
    setState(() {
      this.image = image;
    });
  }

  Future<Widget> getImageFromGallery() async {
    var image = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      this.image = image;
    });
  }
}

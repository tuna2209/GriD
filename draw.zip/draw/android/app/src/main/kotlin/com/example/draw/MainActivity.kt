package com.example.draw

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

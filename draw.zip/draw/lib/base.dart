import 'dart:ui';

import 'package:draw_cover/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_material_color_picker/flutter_material_color_picker.dart';

class BaseGeneration extends State<MyHomePage> {
  MyPainter painter;
  int count = 5;

  ColorSwatch _tempMainColor;
  Color _tempShadeColor;
  ColorSwatch _mainColor = Colors.blue;
  Color _shadeColor = Colors.blue[800];

  BaseGeneration() {
    painter = new MyPainter(context);
    painter.setCount(count);
    painter.setColor(
        _mainColor.alpha, _mainColor.red, _mainColor.green, _mainColor.blue);
  }

  increaseCount() {
    count++;
    painter.setCount(count);
  }

  decreaseCount() {
    count--;
    painter.setCount(count);
  }

  changeColor() async {
    openDialog(
      "Color picker",
      // https://pub.dev/packages/flutter_material_color_picker
      MaterialColorPicker(
        selectedColor: _shadeColor,
        onColorChange: (color) => setState(() => _tempShadeColor = color),
        onMainColorChange: (color) => setState(() => _tempMainColor = color),
        onBack: () => print("Back button pressed"),
      ),
    );
  }

  openDialog(String title, Widget content) {
    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          contentPadding: const EdgeInsets.all(6.0),
          title: Text(title),
          content: content,
          actions: [
            FlatButton(
              child: Text('CANCEL'),
              onPressed: Navigator.of(context).pop,
            ),
            FlatButton(
              child: Text('SUBMIT'),
              onPressed: () {
                Navigator.of(context).pop();
                setState(() => _mainColor = _tempMainColor);
                setState(() => _shadeColor = _tempShadeColor);
                painter.setColor(_mainColor.alpha, _mainColor.red,
                    _mainColor.green, _mainColor.blue);
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    throw UnimplementedError();
  }
}

class MyPainter extends CustomPainter {
  BuildContext context;
  Paint p;
  int w = 0;
  int h = 0;
  int c = 0;

  MyPainter(BuildContext context) {
    this.context = context;
  }

  setColor(int a, int r, int g, int b) {
    p = Paint()
      ..color = Color.fromARGB(a, r, g, b)
      ..strokeWidth = 1
      ..strokeCap = StrokeCap.round;
  }

  setObjectSize(int w, int h) {
    this.w = w;
    this.h = h;
    print("setObjectSize : " + this.w.toString() + " - " + this.h.toString());
  }

  setCount(int c) {
    this.c = c;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (w == 0 || h == 0 || c == 0) {
//      print("don't draw : " +
//          w.toString() +
//          " - " +
//          h.toString() +
//          " - " +
//          c.toString());
      return;
    }

    double s = w / c;
    double horCount = w / s;
    double verCount = h / s;
    double horHalf = h / 2;
    double verHalf = w / 2;
//    print("paint draw : count = " +
//        c.toString() +
//        " - size : " +
//        s.toString() +
//        " - horCount : " +
//        horCount.toString() +
//        " - verCount : " +
//        verCount.toString());

    for (var i = 0; i <= horCount; i++) {
      final pos = -verHalf + i * s;
      final p1 = Offset(pos, -horHalf);
      final p2 = Offset(pos, horHalf);
      canvas.drawLine(p1, p2, p);
    }

    for (var i = 0; i <= verCount; i++) {
      final pos = -horHalf + i * s;
      final p1 = Offset(-verHalf, pos);
      final p2 = Offset(verHalf, pos);
      canvas.drawLine(p1, p2, p);
    }
  }

  @override
  bool shouldRepaint(CustomPainter old) {
    return false;
  }
}
